package edu.txstate.lmy11.hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.DecimalFormat;

public class CarWashActivity extends AppCompatActivity {
    double exteriorWash = 10.50;
    double exteriorWithInteriorWash = 15;
    double totalCost = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_wash);
        EditText numberOfWashes = findViewById(R.id.editTextNumberOfWashes);
        TextView results = findViewById(R.id.txtCarWashTotalCost);
        RadioButton exteriorOnly = findViewById(R.id.rbExteriorOnly);
        RadioButton exteriorAndInterior = findViewById(R.id.rbExteriorWithInteriorClean);

        Button calculateCost = findViewById(R.id.btnCalculatePackageCost);
        calculateCost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double dblConvertedNumberOfWashes = 0;
                try{
                    String strConvertedCost = numberOfWashes.getText().toString();
                    dblConvertedNumberOfWashes = Double.parseDouble(strConvertedCost);
                    if(exteriorOnly.isChecked()) {
                        totalCost = exteriorWash * dblConvertedNumberOfWashes;
                    } else {
                        totalCost = exteriorWithInteriorWash * dblConvertedNumberOfWashes;
                    }
                    DecimalFormat currency = new DecimalFormat("$###,###.00");
                    results.setText("The total cost is: " + currency.format(totalCost));
                }catch (Exception ex){
                    ex.printStackTrace();
                }
            }
        });


    }
}