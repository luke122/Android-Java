package edu.txstate.lmy11.hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

public class CabFareActivity extends AppCompatActivity {
    double initialCost  = 5.50;
    double pricePerMile = 3.25;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cab_fare);

        EditText txtNumberOfMiles  = findViewById(R.id.editTextNumberOfMiles);
        Button calculateFare = findViewById(R.id.btnCalculateFare);
        TextView txtResult = findViewById(R.id.txtResult);
        Spinner spnTypeOfCab = findViewById(R.id.spnTypeOfCab);
        calculateFare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strNumberOfMiles = txtNumberOfMiles.getText().toString();
                double dblNumberOfMiles = 0;
                try {
                    dblNumberOfMiles = Double.parseDouble(strNumberOfMiles);
                    double totalCost = (dblNumberOfMiles * pricePerMile) + initialCost;
                    NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);
                    String cabSelected = spnTypeOfCab.getSelectedItem().toString();
                    txtResult.setText("Your total cost is " + currencyFormat.format(totalCost) + "; your cab selection is " + cabSelected);
                } catch (Exception ex){
                    ex.printStackTrace();
                }
            }
        });
    }

}