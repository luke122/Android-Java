package edu.txstate.lmy11.test1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    double standard = 4.5;
    double priority = 6.25;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText weight = findViewById(R.id.editTextWeight);
        RadioButton standardShipping = findViewById(R.id.rbStandard);
        RadioButton priorityShipping = findViewById(R.id.rbPriority);
        Spinner carrier = findViewById(R.id.spnCarrier);
        TextView result = findViewById(R.id.txtResult);

        Button calculateCost = findViewById(R.id.btnGetTheCost);
        calculateCost.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                double dblWeight = 0;
                double totalCost = 0;
                try{
                    String strConvertedWeight = weight.getText().toString();
                    dblWeight = Double.parseDouble(strConvertedWeight);
                    DecimalFormat currency = new DecimalFormat("$###,###.00");
                    String carrierSelected = carrier.getSelectedItem().toString();
                    if (standardShipping.isChecked()){
                        totalCost = standard * dblWeight;

                    }else{
                        totalCost = priority * dblWeight;

                    }
                    if(dblWeight > 100){
                        startActivity(new Intent(MainActivity.this, SpecialShipmentScreenActivity.class));
                    }
                    result.setText("The cost is: " + currency.format(totalCost) + "; the carrier selected is " + carrierSelected);

                }catch (Exception ex){
                    ex.printStackTrace();
                }
            }
        });
    }
}