package edu.txstate.lmy11.test1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SpecialShipmentScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_special_shipment_screen);
    }
}